#ifndef CUB3D_H

#include "ft_printf/ft_printf.h"
#include "libft/libft.h"
#include "gnl/get_next_line.h"
#include <fcntl.h>

typedef struct s_player_position
{
  int x;
  int y;
} t_player_position;

typedef struct s_data
{
	char **file_data;
	char *file_str;
	int line_count;
	char *no_texture;
	char *so_texture;
	char *we_texture;
	char *ea_texture;
	int floor[3];
	int ceiling[3];
	char **map;
	char **map_copy;
	int map_height;
	int map_width;
  t_player_position player_position;
  char player_char;
} t_data;


void get_number_of_lines(char *path, t_data *data);
void check_file_validity(t_data *data, char *file_str);
void get_file_data(t_data *data);
void extract_textures(t_data *data);
void extract_floor_and_ceiling(t_data *data);
void do_premap_elements_exist(t_data *data);
void extract_map(t_data *data);
void map_validation(t_data *data);
void create_map_copy(t_data *data);
void invoke_flood(t_data *data);
void init_reset_data(t_data *data);
void free_data(t_data *data);
void ft_exit_failure(t_data *data, char *msg);
void validate_textures(t_data *data);
void check_is_directory(t_data *data, char *texture);
void check_is_fd_valid(t_data *data, char *texture);
void check_xpm_extention(t_data *data, char *texture);
void check_ranges(t_data *data);

#endif
