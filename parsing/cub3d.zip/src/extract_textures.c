#include "../cub3d.h"

void get_no_texture(t_data *data, char *line)
{
	char *text = NULL;

	if (ft_strnstr(line, "NO ", 3))
	{
    // flag duplication function
    if (data->no_texture)
      ft_exit_failure(data, "{-} duplicated texture!");
		text = ft_strtrim(line + 3, " \t\n");
		data->no_texture = ft_strdup(text);
    free(text);
    text = NULL;
	}
}

void get_so_texture(t_data *data, char *line)
{
	char *text = NULL;

	if (ft_strnstr(line, "SO ", 3))
	{
    if (data->so_texture)
      ft_exit_failure(data, "{-} duplicated texture!");
		text = ft_strtrim(line + 3, " \t\n");
		data->so_texture = ft_strdup(text);
    free(text);
    text = NULL;
	}
}

void get_ea_texture(t_data *data, char *line)
{
	char *text = NULL;
	if (ft_strnstr(line, "EA ", 3))
	{
    if (data->ea_texture)
      ft_exit_failure(data, "{-} duplicated texture!");
		text = ft_strtrim(line + 3, " \t\n");
		data->ea_texture = ft_strdup(text);
    free(text);
    text = NULL;
	}
}

void get_we_texture(t_data *data, char *line)
{
	char *text = NULL;
	if (ft_strnstr(line, "WE ", 3))
	{
    if (data->we_texture)
      ft_exit_failure(data, "{-} duplicated texture!");
		text = ft_strtrim(line + 3, " \t\n");
		data->we_texture = ft_strdup(text);
    free(text);
    text = NULL;
	}
}

void extract_textures(t_data *data)
{
	int i = 0;
	while (data->file_data[i])
	{
		get_no_texture(data, data->file_data[i]);
		get_so_texture(data, data->file_data[i]);
		get_ea_texture(data, data->file_data[i]);
		get_we_texture(data, data->file_data[i]);
		i++;
	}
}

// you can use the same technique to extract Floor and ceiling chars
// and for the rgb colors, you can use split by comma
// and then use strtrim the spaces again
