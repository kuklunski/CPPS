// what are all the scenarious that can happen when running this code? 
//
// all those conditions? what are they protecting against? 
//
// i need to invoke every error to understand this better
//
// i need to go through with it using gdb
// 
//
// i need to write this thing myself and use each function on its own to really know what it does
//
// that printing function alone needs some time to get and to really understand closing file descriptors
