#include <stdio.h>

// what does this return? (it's type)
// what does it take as argument? 
// it's purpose? who uses it? 
// how does it work? 
// how can i use these functions to make something that functions like it?
// Allowed functions: pipe, fork, dup2, execvp, close, exit
void ft_popen()
{
}

int main(void)
{
	printf("this is working\n");
	return (0);
}
